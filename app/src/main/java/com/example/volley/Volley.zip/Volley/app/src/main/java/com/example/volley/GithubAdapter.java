package com.example.volley;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
public class GithubAdapter extends RecyclerView.Adapter<GithubAdapter.GithubViewHolder> {
    
    private Context mContext;
    private User[] mUser;

    public GithubAdapter(Context context, User[] data) {
        mContext = context;
        mUser = data;
    }

    @NonNull
    @Override
    public GithubViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull GithubViewHolder holder, int position) {
    }

    @Override
    public int getItemCount() {
        return mUser.length;
    }

    public class GithubViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;

        public GithubViewHolder(@NonNull View itemView) {
            super( itemView );
            imageView = itemView.findViewById( R.id.imageUser );
            textView = itemView.findViewById( R.id.textUser );
        }
    }
}
